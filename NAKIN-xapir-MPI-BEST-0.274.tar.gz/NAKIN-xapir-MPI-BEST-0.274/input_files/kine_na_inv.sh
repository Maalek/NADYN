#!/bin/sh

rm -f *~
rm -f kine_files/*~

date > kine_na.out
../bin/kine_na_inversion >> kine_na.out
date >> kine_na.out
