#!/bin/env python

from pylab import *

nr = 11

out = open('station.dat','r')
xr  = arange(nr)*1.
yr  = arange(nr)*1.
zr  = arange(nr)*1.
j   = 0
for line in out:
	(ind,ns,ew,ud,) = line.split()[0:4]
	xr[j]        = float(ew)
	yr[j]        = float(ns)
	zr[j]        = float(ud)
	j            = j + 1
out.close()

ns = 2556

out = open('source.dat','r')
xs  = arange(ns)*1.
ys  = arange(ns)*1.
zs  = arange(ns)*1.
j   = 0
for line in out:
	print line
	(ind,ns,ew,ud,) = line.split()[0:4]
	xs[j]        = float(ew)
	ys[j]        = float(ns)
	zs[j]        = float(ud)
	j            = j + 1
out.close()


plot(xr/1000.,yr/1000.,'rp')
plot(xs/1000.,ys/1000.,'bx')
axis('equal')
show()
