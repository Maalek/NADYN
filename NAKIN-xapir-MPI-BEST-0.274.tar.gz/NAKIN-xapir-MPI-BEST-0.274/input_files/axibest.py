#!/bin/env python

from pylab import *

ns = 2556
nx = 71
ny = 36
dx = 0.5
nc = 7

out  = open('axi.hist','r')
disp = arange(ns)*1.
trup = arange(ns)*1.
j    = 0
for line in out:
	(ind,slip,strike,dip,rake,length,width,delay,rise,) = line.split()[0:9]
	disp[j] = float(slip)
	trup[j] = float(delay)
	j       = j + 1
out.close()


disp.shape = ny,nx
trup.shape = ny,nx
x          = arange(nx)
y          = arange(ny)

subplot(2,1,1)
pcolor(x*dx,y*dx,disp,cmap='gray_r')
xlim(min(x*dx),max(x*dx))
ylim(min(y*dx),max(y*dx))
ax = gca()
ax.set_aspect('equal')
ax.invert_yaxis()
grid('on')
colorbar(shrink=1)

out = open('axi.data','r')
depth = arange(nc)*1.
vs    = arange(nc)*1.
rho   = arange(nc)*1.
j     = 0
i     = 0
for line in out:
	if (j >= 16):
		(dph,pw,sw,den,qp,qs,) = line.split()[0:6]
		depth[i] = float(dph)
		vs[i]    = float(sw)
		rho[i]   = float(den)
		i        = i + 1
	j = j + 1	
out.close()

out = open('source.dat','r')
zs  = arange(ns)*1.
j   = 0
for line in out:
	(ind,x,y,z,) = line.split()[0:4]
	zs[j]        = float(z)
	j            = j + 1

mu = arange(ns)*1.
for i in range(ns):
	if (nc > 1):
		for j in range(nc-1):
			if ((zs[i] >= depth[j]) and (zs[i] < depth[j+1])): mu[i] = vs[j]*vs[j]*rho[j]
	elif (nc == 1):
		mu[i] = vs[0]*vs[0]*rho[0]	
mu.shape = ny,nx
print "Seismic moment =",sum(disp*mu*(dx*1000.*dx*1000.))

x = arange(nx)
y = arange(ny)
subplot(2,1,2)
pcolor(x*dx,y*dx,trup,cmap='gray_r')
xlim(min(x*dx),max(x*dx))
ylim(min(y*dx),max(y*dx))
ax = gca()
ax.set_aspect('equal')
ax.invert_yaxis()
grid('on')
colorbar(shrink=1)
xlabel('Dist. along strike (km)')
ylabel('Depth (km)')
show()

