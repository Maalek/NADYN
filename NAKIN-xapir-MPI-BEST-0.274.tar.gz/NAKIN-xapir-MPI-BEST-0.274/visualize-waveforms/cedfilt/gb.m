clc;
clear;
clear all;
nrealall=importdata('real_disp_x');
erealall=importdata('real_disp_y');
zrealall=importdata('real_disp_z');


nsynall=importdata('best_disp_x');
esynall=importdata('best_disp_y');
zsynall=importdata('best_disp_z');

wavrealall(:,1)=nrealall(:,1);
wavrealall(:,2)=erealall(:,1);
wavrealall(:,3)=zrealall(:,1);

wavsynall(:,1)=nsynall(:,1);
wavsynall(:,2)=esynall(:,1);
wavsynall(:,3)=zsynall(:,1);

nsynreal(:,1)=nrealall(:,1);
nsynreal(:,2)=nsynall(:,1);


%%% waveforms separation N
k=1;
for i=1:11
    for j=1:512
     stanreal(j,k)=nrealall(((512*(k-1))+j),1);
    end
    k=k+1;
end
    
k=1;
for i=1:11
    for j=1:512
     stansyn(j,k)=nsynall(((512*(k-1))+j),1);
    end
    k=k+1;
end


%%% waveforms separation E
k=1;
for i=1:11
    for j=1:512
     staereal(j,k)=erealall(((512*(k-1))+j),1);
    end
    k=k+1;
end
    
k=1;
for i=1:11
    for j=1:512
     staesyn(j,k)=esynall(((512*(k-1))+j),1);
    end
    k=k+1;
end

%%% waveforms separation Z
k=1;
for i=1:11
    for j=1:512
     stazreal(j,k)=zrealall(((512*(k-1))+j),1);
    end
    k=k+1;
end
    
k=1;
for i=1:11
    for j=1:512
     stazsyn(j,k)=zsynall(((512*(k-1))+j),1);
    end
    k=k+1;
end

%%%%%%%%%%%%
%%%%%%%%%%%%    STA 1
%%%%%%%%%%%%%%%


%%% waveform fits , N component for sta 1
ncomparsta1(:,1)=stanreal(:,1);
ncomparsta1(:,2)=stansyn(:,1);

%%% waveform fits , E component for sta 1 
ecomparsta1(:,1)=staereal(:,1);
ecomparsta1(:,2)=staesyn(:,1);

%%% waveform fits , Z component for sta 1 
zcomparsta1(:,1)=stazreal(:,1);
zcomparsta1(:,2)=stazsyn(:,1);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 2
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 2 
ncomparsta2(:,1)=stanreal(:,2);
ncomparsta2(:,2)=stansyn(:,2);

%%% waveform fits , E component for sta 2 
ecomparsta2(:,1)=staereal(:,2);
ecomparsta2(:,2)=staesyn(:,2);

%%% waveform fits , Z component for sta 2 
zcomparsta2(:,1)=stazreal(:,2);
zcomparsta2(:,2)=stazsyn(:,2);

%%%%%%%%%%%%
%%%%%%%%%%%%    STA 3
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 3
ncomparsta3(:,1)=stanreal(:,3);
ncomparsta3(:,2)=stansyn(:,3);

%%% waveform fits , E component for sta 3
ecomparsta3(:,1)=staereal(:,3);
ecomparsta3(:,2)=staesyn(:,3);

%%% waveform fits , Z component for sta 3
zcomparsta3(:,1)=stazreal(:,3);
zcomparsta3(:,2)=stazsyn(:,3);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 4
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 4 
ncomparsta4(:,1)=stanreal(:,4);
ncomparsta4(:,2)=stansyn(:,4);

%%% waveform fits , E component for sta 4 
ecomparsta4(:,1)=staereal(:,4);
ecomparsta4(:,2)=staesyn(:,4);

%%% waveform fits , Z component for sta 4 
zcomparsta4(:,1)=stazreal(:,4);
zcomparsta4(:,2)=stazsyn(:,4);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 5
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 5 
ncomparsta5(:,1)=stanreal(:,5);
ncomparsta5(:,2)=stansyn(:,5);

%%% waveform fits , E component for sta 5 
ecomparsta5(:,1)=staereal(:,5);
ecomparsta5(:,2)=staesyn(:,5);

%%% waveform fits , Z component for sta 5 
zcomparsta5(:,1)=stazreal(:,5);
zcomparsta5(:,2)=stazsyn(:,5);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 6
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 6 
ncomparsta6(:,1)=stanreal(:,6);
ncomparsta6(:,2)=stansyn(:,6);

%%% waveform fits , E component for sta 6 
ecomparsta6(:,1)=staereal(:,6);
ecomparsta6(:,2)=staesyn(:,6);

%%% waveform fits , Z component for sta 6 
zcomparsta6(:,1)=stazreal(:,6);
zcomparsta6(:,2)=stazsyn(:,6);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 7
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 7 
ncomparsta7(:,1)=stanreal(:,7);
ncomparsta7(:,2)=stansyn(:,7);

%%% waveform fits , E component for sta 7 
ecomparsta7(:,1)=staereal(:,7);
ecomparsta7(:,2)=staesyn(:,7);

%%% waveform fits , Z component for sta 7 
zcomparsta7(:,1)=stazreal(:,7);
zcomparsta7(:,2)=stazsyn(:,7);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 8
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 8 
ncomparsta8(:,1)=stanreal(:,8);
ncomparsta8(:,2)=stansyn(:,8);

%%% waveform fits , E component for sta 8 
ecomparsta8(:,1)=staereal(:,8);
ecomparsta8(:,2)=staesyn(:,8);

%%% waveform fits , Z component for sta 8 
zcomparsta8(:,1)=stazreal(:,8);
zcomparsta8(:,2)=stazsyn(:,8);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 9
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 9 
ncomparsta9(:,1)=stanreal(:,9);
ncomparsta9(:,2)=stansyn(:,9);

%%% waveform fits , E component for sta 9 
ecomparsta9(:,1)=staereal(:,9);
ecomparsta9(:,2)=staesyn(:,9);

%%% waveform fits , Z component for sta 9 
zcomparsta9(:,1)=stazreal(:,9);
zcomparsta9(:,2)=stazsyn(:,9);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 10
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 10 
ncomparsta10(:,1)=stanreal(:,10);
ncomparsta10(:,2)=stansyn(:,10);

%%% waveform fits , E component for sta 10 
ecomparsta10(:,1)=staereal(:,10);
ecomparsta10(:,2)=staesyn(:,10);

%%% waveform fits , Z component for sta 10 
zcomparsta10(:,1)=stazreal(:,10);
zcomparsta10(:,2)=stazsyn(:,10);


%%%%%%%%%%%%
%%%%%%%%%%%%    STA 11
%%%%%%%%%%%%%%%

%%% waveform fits , N component for sta 11 
ncomparsta11(:,1)=stanreal(:,11);
ncomparsta11(:,2)=stansyn(:,11);

%%% waveform fits , E component for sta 11 
ecomparsta11(:,1)=staereal(:,11);
ecomparsta11(:,2)=staesyn(:,11);

%%% waveform fits , Z component for sta 11 
zcomparsta11(:,1)=stazreal(:,11);
zcomparsta11(:,2)=stazsyn(:,11);


%%%% Visualize
figure

subplot(11,3,1);
plot(ncomparsta1,'DisplayName','ncomparsta1')
title('N')

subplot(11,3,2);
plot(ecomparsta1,'DisplayName','ecomparsta1')
title('E')
subplot(11,3,3);
plot(zcomparsta1,'DisplayName','zcomparsta1')
title('Z')
 subplot(11,3,4);
 plot(ncomparsta2,'DisplayName','ncomparsta2')
 subplot(11,3,5);
 plot(ecomparsta2,'DisplayName','ecomparsta2')
 subplot(11,3,6);
 plot(zcomparsta2,'DisplayName','zcomparsta2')

 subplot(11,3,7);
 plot(ncomparsta3,'DisplayName','ncomparsta3')
 subplot(11,3,8);
 plot(ecomparsta3,'DisplayName','ecomparsta3')
 subplot(11,3,9);
 plot(zcomparsta3,'DisplayName','zcomparsta3')
 
subplot(11,3,10);
plot(ncomparsta4,'DisplayName','ncomparsta4')
subplot(11,3,11);
plot(ecomparsta4,'DisplayName','ecomparsta4')
subplot(11,3,12);
plot(zcomparsta4,'DisplayName','zcomparsta4')

subplot(11,3,13);
plot(ncomparsta5,'DisplayName','ncomparsta5')
ylabel('Displacement(meter)')
subplot(11,3,14);
plot(ecomparsta5,'DisplayName','ecomparsta5')
subplot(11,3,15);
plot(zcomparsta5,'DisplayName','zcomparsta5')

subplot(11,3,16);
plot(ncomparsta6,'DisplayName','ncomparsta6')


subplot(11,3,17);
plot(ecomparsta6,'DisplayName','ecomparsta6')
subplot(11,3,18);
plot(zcomparsta6,'DisplayName','zcomparsta6')

subplot(11,3,19);
plot(ncomparsta7,'DisplayName','ncomparsta7')
subplot(11,3,20);
plot(ecomparsta7,'DisplayName','ecomparsta7')
subplot(11,3,21);
plot(zcomparsta7,'DisplayName','zcomparsta7')

subplot(11,3,22);
plot(ncomparsta8,'DisplayName','ncomparsta8')
subplot(11,3,23);
plot(ecomparsta8,'DisplayName','ecomparsta8')
subplot(11,3,24);
plot(zcomparsta8,'DisplayName','zcomparsta8')

subplot(11,3,25);
plot(ncomparsta9,'DisplayName','ncomparsta9')
subplot(11,3,26);
plot(ecomparsta9,'DisplayName','ecomparsta9')
subplot(11,3,27);
plot(zcomparsta9,'DisplayName','zcomparsta9')

subplot(11,3,28);
plot(ncomparsta10,'DisplayName','ncomparsta10')
subplot(11,3,29);
plot(ecomparsta10,'DisplayName','ecomparsta10')
subplot(11,3,30);
plot(zcomparsta10,'DisplayName','zcomparsta10')

subplot(11,3,31);
plot(ncomparsta11,'DisplayName','ncomparsta11')
xlabel('Time(sec)')
subplot(11,3,32);
plot(ecomparsta11,'DisplayName','ecomparsta11')
xlabel('Time(sec)')
subplot(11,3,33);
plot(zcomparsta11,'DisplayName','zcomparsta11')
xlabel('Time(sec)')


