#!/bin/env python

from numpy import *
from matplotlib.pyplot import *

nx = 100
nz = 100

Tu       = loadtxt('result/stressin.dat')/1.0E+6
Tu.shape = nz,nx 

SD       = loadtxt('result/peakin.dat')/1.0E+6
SD.shape = nz,nx 

subplot(121); pcolor(Tu); xlim(0,nx); ylim(0,nz); gca().set_aspect(1); 
title('Yield stress (MPa)'); colorbar(shrink=0.5); ylabel('<-- Bottom / Top -->')

subplot(122); pcolor(SD); xlim(0,nx); ylim(0,nz); gca().set_aspect(1); 
title('Background stress (MPa)'); colorbar(shrink=0.5)

show()
