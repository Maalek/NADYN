#!/bin/env python

from pylab import *

figure(1)
out  = open('misfits.dat','r')
j    = 0
misf = []
for line in out:
	(misfit,) = line.split()[0:1]
	misf.append(float(misfit))
out.close()

nm = len(misf)

x = arange(nm)
scatter(x,misf,s=x*0.+100.,c=misf,alpha=0.5,edgecolors='none')
xlim(min(x),max(x))
ylim(min(misf),max(misf))
xlabel('Number of models')
ylabel('Misfit')

show()


