#!/bin/env python

from numpy import *
from matplotlib.pyplot import *

nx = 100
nz = 100

slip       = loadtxt('result/slip.res')
slip.shape = nz,nx 

trup       = loadtxt('result/ruptime.res')
trup.shape = nz,nx 

rise       = loadtxt('result/risetime.res')
rise.shape = nz,nx

stress       = loadtxt('result/stressdrop.res')/1.0E+6
vmax         = max(abs((stress)))/4
stress.shape = nz,nx

subplot(221); pcolor(slip); xlim(0,nx); ylim(0,nz); gca().set_aspect(1); 
title('Slip (m)'); colorbar(shrink=0.8); ylabel('<-- Bottom / Top -->')

subplot(222); pcolor(trup); xlim(0,nx); ylim(0,nz); gca().set_aspect(1); 
title('Rupture time (s)'); colorbar(shrink=0.8)

subplot(223); pcolor(rise); xlim(0,nx); ylim(0,nz); gca().set_aspect(1); 
title('Rise time (s)'); colorbar(shrink=0.8)

subplot(224); pcolor(stress,cmap='RdBu'); xlim(0,nx); ylim(0,nz); gca().set_aspect(1); 
title('Stress Change (MPa)'); colorbar(shrink=0.8)
clim(-vmax,+vmax)

show()
