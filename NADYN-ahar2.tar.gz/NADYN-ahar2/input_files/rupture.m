clear all; clc; close all;

ntfd      = 2000;
ntiskp    = 20;
nt        = ntfd/ntiskp;
nxfd      = 100;
nzfd      = 100;
nxax      =  50;
nzax      =  50;
ntax      = 256;

srate_fd  = load('result/sliprate.res');
vmax      = max(srate_fd);
srate_fd  = reshape(srate_fd,nxfd,nzfd,nt);

srate_axi = load('result/sliprate.axi');
srate_axi = reshape(srate_axi,ntax,nxax,nzax);

for it = 1:nt
    subplot(1,2,1);
    srate(:,:) = srate_fd(:,:,it);
    imagesc(srate);
    axis equal;
    xlabel('<-- Bottom/Top -->');
    xlim([1 nxfd]);
    ylim([1 nzfd]);
    
    subplot(1,2,2);
    srateaxi(:,:) = srate_axi(it,:,:);
    imagesc(srateaxi);
    axis equal;
    xlabel('<-- Top/Bottom -->');
    xlim([1 nxax]);
    ylim([1 nzax]);
    
    pause(0.05);
end